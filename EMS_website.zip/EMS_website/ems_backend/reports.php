<?php
function handleReports(PDO $pdo) {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json");

    // 📊 Yield Data
    $yield = [
        "labels" => [],
        "estimated" => [],
        "actual" => []
    ];

    try {
        $yieldQuery = $pdo->query("SELECT crop AS crop_name, predicted_yield, past_yield FROM yield_predictions ORDER BY created_at DESC LIMIT 10");
        $yieldData = $yieldQuery->fetchAll(PDO::FETCH_ASSOC);

        foreach ($yieldData as $row) {
            $yield["labels"][] = $row["crop_name"];
            $yield["estimated"][] = (float)$row["predicted_yield"];
            $yield["actual"][] = (float)$row["past_yield"];
        }
    } catch (Exception $e) {
        $yield = ["labels" => [], "estimated" => [], "actual" => []];
    }

    // 🧠 Yield Accuracy Calculation
    $accuracy = 0.0;
    try {
        $all = $pdo->query("SELECT predicted_yield, past_yield FROM yield_predictions")->fetchAll(PDO::FETCH_ASSOC);
        $accuracies = [];

        foreach ($all as $row) {
            if ($row['past_yield'] > 0) {
                $acc = 100 - abs($row['predicted_yield'] - $row['past_yield']) / $row['past_yield'] * 100;
                $accuracies[] = max(0, min(100, $acc));
            }
        }

        $accuracy = count($accuracies) ? round(array_sum($accuracies) / count($accuracies), 1) : 0.0;
    } catch (Exception $e) {
        $accuracy = 0.0;
    }

    // 🛠️ Equipment Summary
    $equipment = [
        "working" => 0,
        "broken" => 0,
        "maintenance" => 0
    ];

    try {
        $eqQuery = $pdo->query("SELECT status, COUNT(*) as count FROM equipment_status GROUP BY status");
        foreach ($eqQuery->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $status = strtolower($row['status']);
            if (isset($equipment[$status])) {
                $equipment[$status] = (int)$row['count'];
            }
        }
    } catch (Exception $e) {
        
    }

    // 📅 Summary
    $summary = [
        "yield_accuracy" => $accuracy,
        "reminders" => 0,
        "user_logins" => [],
        "new_crops" => 0,
        "equipment_updates" => 0
    ];

    try {
        $summary["reminders"] = (int)$pdo->query("SELECT COUNT(*) FROM reminders WHERE MONTH(date_time) = MONTH(CURDATE()) AND YEAR(date_time) = YEAR(CURDATE())")->fetchColumn();
        $summary["user_logins"] = $pdo->query("SELECT username, last_login FROM users")->fetchAll(PDO::FETCH_ASSOC);
        $summary["new_crops"] = (int)$pdo->query("SELECT COUNT(*) FROM crops WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->fetchColumn();
        $summary["equipment_updates"] = (int)$pdo->query("SELECT COUNT(*) FROM equipment_status WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->fetchColumn();
    } catch (Exception $e) {
        
    }

    // ✅ Final JSON response
    echo json_encode([
        "yield" => $yield,
        "equipment" => $equipment,
        "summary" => $summary
    ]);
}