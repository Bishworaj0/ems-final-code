<?php
// Route detection
$route = $_GET['route'] ?? '';
$request_method = $_SERVER['REQUEST_METHOD'];
$userRole = $_SERVER['HTTP_X_USER_ROLE'] ?? '';

file_put_contents("api_debug.log", print_r([
    'route' => $route,
    'method' => $request_method,
    'body' => file_get_contents("php://input")
  ], true), FILE_APPEND);

$raw = file_get_contents("php://input");
file_put_contents("debug_raw_input.log", $raw . "\n", FILE_APPEND);

$body = json_decode($raw, true); // <-- THE variable to use

// CORS HEADERS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-User-Role");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header("Content-Type: application/json");

// Database connection
$host = 'localhost';
$db = 'ems';
$user = 'root';
$pass = 'root';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection failed: " . $e->getMessage()]);
    exit;
}


// 🧭 Main Routing Switch
switch ($route) {
    case 'reset_password':
        require_once 'reset_password.php';
        handlePasswordReset($pdo);
        break;

    case 'reminders':
        require_once 'reminders.php';
        handleReminders($pdo, $request_method);
        break;

    case 'login':
        require_once 'login.php';
        handleLogin($pdo, $request_method);
        break;

    case 'admin_login':
        require_once 'admin_login.php';
        handleAdminLogin($pdo);
        break;

    case 'crops':
        require_once 'crops.php';
        handleCrops($pdo, $request_method);
        break;

    case 'field_capacity':
        require_once 'field_capacity.php';
        handleFieldCapacity($pdo, $request_method);
        break;

    case 'yield_forecast':
        require_once 'yield_forecast.php';
        handleYieldForecast($pdo, $_SERVER['REQUEST_METHOD']);
        break;

    case 'equipment_status':
        require_once 'equipment_status.php';
        handleEquipmentStatus($pdo, $request_method);
        break;

    case 'users':
        require_once 'users.php';
        handleUsers($pdo, $request_method);
        break;

    case 'reports':
        require_once 'reports.php';
        handleReports($pdo);
        break;

    case 'activity_summary':
        require_once 'activity_summary.php';
        handleActivitySummary($pdo);
        break;
        case 'suggestions':
            require_once 'suggestions.php';
            handleSuggestions($pdo);
            break;
            case 'accounts':
                require_once 'accounts.php';
                handleAccounts($pdo, $request_method);
                break;
                case 'send_reminders':
                    require_once 'send_reminders.php';
                    break;
            case 'weekly_growth':
                        require_once 'weekly_growth.php';
                        handleWeeklyGrowth($pdo, $_SERVER['REQUEST_METHOD']);
                        break;
                      
    default:
        echo json_encode(["message" => "EMS Backend API running"]);
        break;
}