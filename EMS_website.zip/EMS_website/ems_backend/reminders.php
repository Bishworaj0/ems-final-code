<?php

function handleReminders($pdo, $method) {
    $data = json_decode(file_get_contents("php://input"), true) ?? [];

    switch ($method) {
        case 'GET':
            $stmt = $pdo->query("SELECT * FROM reminders ORDER BY date_time ASC");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;

        case 'POST':
            if (!isset($data['title'], $data['date_time'], $data['notes'])) {
                http_response_code(400);
                echo json_encode(["error" => "Missing fields"]);
                return;
                exec("php /Applications/MAMP/htdocs/EMS_website/ems_backend/send_reminders.php > /dev/null 2>&1 &");
            }

            // Optional email handling
            $title = $data['title'];
            $date_time = $data['date_time'];
            $notes = $data['notes'];
            $email = $data['email'] ?? null;  // optional
            $email_sent = 0;

            $stmt = $pdo->prepare("
                INSERT INTO reminders (title, date_time, notes, email, email_sent, completed)
                VALUES (?, ?, ?, ?, ?, 0)
            ");

            $stmt->execute([$title, $date_time, $notes, $email, $email_sent]);

            echo json_encode(["message" => "Reminder added successfully and email will be sent."]);
            break;

        case 'DELETE':
            if (!isset($data['id'])) {
                http_response_code(400);
                echo json_encode(["error" => "Missing reminder ID"]);
                return;
            }

            $stmt = $pdo->prepare("DELETE FROM reminders WHERE id = ?");
            $stmt->execute([$data['id']]);
            echo json_encode(["message" => "Reminder deleted"]);
            break;

        default:
            http_response_code(405);
            echo json_encode(["error" => "Method not allowed"]);
            break;
    }
}