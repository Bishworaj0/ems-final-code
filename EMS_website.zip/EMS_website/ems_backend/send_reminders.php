<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// DB Connection
$host = 'localhost';
$db = 'ems';
$user = 'root';
$pass = 'root';

try {
    $pdo = new PDO("mysql:host=$host;port=8889;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    date_default_timezone_set("Australia/Sydney");
} catch (PDOException $e) {
    echo json_encode(["error" => "DB connection failed", "details" => $e->getMessage()]);
    exit;
}

// Fetch reminders
$stmt = $pdo->prepare("SELECT * FROM reminders WHERE email_sent = 0 AND date_time <= NOW()");
$stmt->execute();
$reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($reminders)) {
    echo json_encode(["message" => "No due reminders right now."]);
    exit;
}

$sent = 0;
$failed = 0;

foreach ($reminders as $reminder) {
    $mail = new PHPMailer(true);
    $mail->SMTPDebug = 0;
    $mail->Debugoutput = 'error_log';

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'bishworajchaulagain7@gmail.com';
        $mail->Password   = 'fipt byga ripa muml'; // 
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->isHTML(true);
        $mail->setFrom('bishworajchaulagain7@gmail.com', 'EMS Reminder Bot');

        $recipients = explode(',', $reminder['email']);
        foreach ($recipients as $email) {
            $mail->addAddress(trim($email));
        }

        $mail->Subject = "⏰ Reminder: " . $reminder['title'];
        $mail->Body = "
            <h2>⏰ Farm Reminder</h2>
            <p><strong>Title:</strong> {$reminder['title']}</p>
            <p><strong>Time:</strong> {$reminder['date_time']}</p>
            <p><strong>Notes:</strong> {$reminder['notes']}</p>
            <hr><small>— EMS Smart Farming System</small>
        ";

        if ($mail->send()) {
            $stmt = $pdo->prepare("UPDATE reminders SET email_sent = 1 WHERE id = ?");
            $stmt->execute([$reminder['id']]);
            $sent++;
        } else {
            error_log("❌ Failed to send email to {$reminder['email']}: " . $mail->ErrorInfo);
            $failed++;
        }

    } catch (Exception $e) {
        error_log("❌ Exception: " . $e->getMessage());
        $failed++;
    }
}

echo json_encode([
    "message" => "Email sending completed",
    "sent" => $sent,
    "failed" => $failed,
    "total" => count($reminders)
]);