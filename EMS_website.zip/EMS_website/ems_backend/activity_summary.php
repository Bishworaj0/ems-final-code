<?php
function handleActivitySummary($pdo) {
  $summary = [];

  // Total crops, users, equipment, reminders
  $summary['total_crops'] = $pdo->query("SELECT COUNT(*) FROM crops")->fetchColumn();
  $summary['total_users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
  $summary['total_equipment'] = $pdo->query("SELECT COUNT(*) FROM equipment_status")->fetchColumn();
  $summary['total_reminders'] = $pdo->query("SELECT COUNT(*) FROM reminders")->fetchColumn();

  echo json_encode($summary);
}