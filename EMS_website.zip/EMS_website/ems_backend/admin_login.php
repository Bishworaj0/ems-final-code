<?php
function handleAdminLogin($pdo) {
    $data = json_decode(file_get_contents("php://input"), true);
    $username = $data["username"] ?? '';
    $password = $data["password"] ?? '';

    if (!$username || !$password) {
        http_response_code(400);
        echo json_encode(["error" => "Username and password required"]);
        return;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(401);
        echo json_encode(["error" => "User not found"]);
        return;
    }

    if (!password_verify($password, $user["password_hash"])) {
        http_response_code(403);
        echo json_encode(["error" => "Password incorrect"]);
        return;
    }

    if ($user["role"] !== "admin") {
        http_response_code(403);
        echo json_encode(["error" => "Access denied: Admins only"]);
        return;
    }

    // ✅ Success
    echo json_encode([
        "message" => "Login successful",
        "user" => [
            "id" => $user["id"],
            "username" => $user["username"],
            "role" => $user["role"]
        ]
    ]);
}