<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$apiKey = 'AIzaSyBpj3KpzC3MX5grreR7VR8vI4AeoX8U6_AQ'; 
$endpoint = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent";

$input = json_decode(file_get_contents("php://input"), true);
$prompt = $input['prompt'] ?? '';

if (!$prompt) {
    echo json_encode(["error" => "Missing prompt"]);
    exit;
}

$payload = json_encode([
    "contents" => [[ "parts" => [[ "text" => $prompt ]] ]]
]);
sleep(1); 

$ch = curl_init($endpoint . "?key=" . $apiKey);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    http_response_code($httpCode);
    echo json_encode(["error" => "Gemini API error", "code" => $httpCode, "response" => $response]);
} else {
    echo $response;
}
session_start();
if (!isset($_SESSION['last_request'])) {
    $_SESSION['last_request'] = time();
} elseif (time() - $_SESSION['last_request'] < 2) {
    http_response_code(429);
    echo json_encode(["error" => "Too many requests, slow down"]);
    exit;
}
$_SESSION['last_request'] = time();

