<?php
function handleYieldForecast($pdo, $method) {

  $body = json_decode(file_get_contents("php://input"), true) ?? [];

  if ($method === 'POST') {
    $crop = $body['crop'] ?? '';
    $past_yield = floatval($body['past_yield'] ?? 0);

    if (!$crop || !$past_yield) {
      echo json_encode(["error" => "Missing fields"]);
      return;
    }

    // 🌤️ Fetch current weather
    $weatherApiKey = '55ebd61504d24f17929120237251104';
    $city = 'Canberra';
    $weatherUrl = "https://api.weatherapi.com/v1/current.json?key={$weatherApiKey}&q={$city}";

    $weatherJson = @file_get_contents($weatherUrl);
    $temp_c = null;
    $weather_desc = null;

    if ($weatherJson !== false) {
      $weatherData = json_decode($weatherJson, true);
      $temp_c = $weatherData['current']['temp_c'] ?? null;
      $weather_desc = $weatherData['current']['condition']['text'] ?? null;
    }

    // 🤖 Predict using Python model (if temp/humidity is available)
    if ($temp_c !== null) {
      $humidity = $weatherData['current']['humidity'] ?? 60;

      // Replace this path with where your model and Python file live
      $pythonScript = escapeshellcmd("python3 /Applications/MAMP/htdocs/EMS_website/predict_yield.py {$temp_c} {$humidity}");
      $predicted_yield = shell_exec($pythonScript);

      // Fallback if Python fails or returns nothing
      if (!$predicted_yield || !is_numeric(trim($predicted_yield))) {
        $base_yield = rand(30, 60);
        $predicted_yield = round($past_yield * 0.5 + $base_yield * 0.5, 2);
      } else {
        $predicted_yield = round(floatval($predicted_yield), 2);
      }
    } else {
      // Use fallback if no temp
      $base_yield = rand(30, 60);
      $predicted_yield = round($past_yield * 0.5 + $base_yield * 0.5, 2);
    }

    $confidence = rand(75, 95); // You can also improve this based on prediction delta

    // 📝 Save to DB
    $stmt = $pdo->prepare("INSERT INTO yield_predictions (crop, past_yield, predicted_yield, confidence, temperature, weather_desc) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$crop, $past_yield, $predicted_yield, $confidence, $temp_c, $weather_desc]);

    echo json_encode([
      "message" => "Prediction complete",
      "predicted_yield" => $predicted_yield,
      "confidence" => $confidence,
      "temp" => $temp_c ?? "N/A",
      "weatherDesc" => $weather_desc ?? "N/A"
    ]);
  }

  // 📜 Fetch prediction history
  else if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM yield_predictions ORDER BY created_at DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
  }

  else {
    http_response_code(405);
    echo json_encode(["error" => "Invalid request method"]);
  }
}