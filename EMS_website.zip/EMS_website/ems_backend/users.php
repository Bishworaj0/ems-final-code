<?php

function handleUsers($pdo, $method) {
  $data = [];

  // Only decode input for methods that include a body
  if (in_array($method, ['POST', 'PUT', 'DELETE'])) {
    $raw = file_get_contents("php://input");
    $data = json_decode($raw, true) ?? [];
    file_put_contents("debug_users.log", print_r($data, true)); 
  }

  // ✅ Admin check (for all non-GET requests)
  $isAdmin = isset($data['admin_role_check']) && $data['admin_role_check'] === 'admin';
  if ($method !== 'GET' && !$isAdmin) {
    http_response_code(403);
    echo json_encode(["error" => "Admins only"]);
    return;
  }

  switch ($method) {
    case 'GET':
      $stmt = $pdo->query("SELECT id, username, email, role, status, last_login FROM users ORDER BY id DESC");
      echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
      break;

    case 'POST':
      $username = $data['username'] ?? '';
      $password = $data['password'] ?? '';
      $email = $data['email'] ?? '';
      $role = $data['role'] ?? 'user';
      $status = $data['userStatus'] ?? 'active';

      if (!$username || !$password || !$email) {
        http_response_code(400);
        echo json_encode(["error" => "All fields are required"]);
        return;
      }

      // Check for duplicate username
      $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
      $check->execute([$username]);
      if ($check->fetchColumn() > 0) {
        http_response_code(400);
        echo json_encode(["error" => "Username already exists"]);
        return;
      }

      $hash = password_hash($password, PASSWORD_DEFAULT);
      $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, email, role, status) VALUES (?, ?, ?, ?, ?)");
      $stmt->execute([$username, $hash, $email, $role, $status]);

      echo json_encode(["message" => "User added"]);
      break;

    case 'PUT':
      $id = $data['id'] ?? null;
      $username = $data['username'] ?? '';
      $email = $data['email'] ?? '';
      $role = $data['role'] ?? '';
      $status = $data['userStatus'] ?? '';

      if (!$id || !$username || !$email || !$role || !$status) {
        http_response_code(400);
        echo json_encode(["error" => "Missing fields"]);
        return;
      }

      $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?");
      $stmt->execute([$username, $email, $role, $status, $id]);

      echo json_encode(["message" => "User updated"]);
      break;

    case 'DELETE':
      $id = $data['id'] ?? null;
      if (!$id) {
        http_response_code(400);
        echo json_encode(["error" => "Missing user ID"]);
        return;
      }

      $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
      $stmt->execute([$id]);

      echo json_encode(["message" => "User deleted"]);
      break;

    default:
      http_response_code(405);
      echo json_encode(["error" => "Method not allowed"]);
      break;
  }
}