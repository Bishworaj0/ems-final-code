<?php
function handleWeeklyGrowth($pdo, $method) {
  header("Content-Type: application/json");
  
  if ($method !== 'GET') {
    echo json_encode(["error" => "Method not allowed"]);
    return;
  }

  $stmt = $pdo->query("SELECT week_number, growth_kg FROM crop_growth WHERE crop_name = 'Wheat' AND year = YEAR(CURDATE()) ORDER BY week_number");
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $labels = [];
  $data = [];

  foreach ($rows as $row) {
    $labels[] = "Week " . $row['week_number'];
    $data[] = $row['growth_kg'];
  }

  echo json_encode([
    "labels" => $labels,
    "data" => $data
  ]);
}