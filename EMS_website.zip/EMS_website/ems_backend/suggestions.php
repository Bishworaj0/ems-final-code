<?php
error_reporting(0); 
ini_set('display_errors', 0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Database config
$host = 'localhost';
$db = 'ems';
$user = 'root';
$pass = 'root';

// Connect to Database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

// 🧠 MAIN SMART SUGGESTION HANDLER
function handleSuggestions($pdo) {
    $tips = [];
    $alerts = [];

    // 1️⃣ CROPS Check
    try {
        $crops = $pdo->query("SELECT * FROM crops")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($crops)) {
            $tips[] = "🌱 No crops planted yet — great time to start sowing!";
        } else {
            foreach ($crops as $crop) {
                $plantedDate = strtotime($crop['planted_on']);
                if ($plantedDate && $plantedDate < strtotime('-5 months')) {
                    $alerts[] = "⚠️ Crop {$crop['crop_name']} planted long ago — check harvest readiness.";
                }
            }
        }
    } catch (PDOException $e) {
        $alerts[] = "⚠️ Could not load crops data.";
    }

   
    // ✅ 2. FIELD CAPACITY
try {
  $field = $pdo->query("SELECT * FROM field_capacity LIMIT 1")->fetch(PDO::FETCH_ASSOC);

  if ($field && isset($field['capacity'])) {
      if ($field['capacity'] < 60) {
          $alerts[] = "💧 Field capacity low ({$field['capacity']}%) — irrigation recommended.";
      } else {
          $tips[] = "✅ Field moisture looks good!";
      }
  } else {
      $alerts[] = "⚠️ No field capacity data available.";
  }
} catch (PDOException $e) {
  $alerts[] = "⚠️ Could not load field data.";
}

    // 3️⃣ EQUIPMENT STATUS (your custom logic)
    try {
        $equipment = $pdo->query("SELECT * FROM equipment_status WHERE last_serviced > 100")->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($equipment)) {
            foreach ($equipment as $equip) {
                $equipName = isset($equip['name']) ? $equip['name'] : 'Unknown Equipment';
                $alerts[] = "🛠️ Equipment '{$equipName}' requires maintenance (last serviced > 100).";
            }
        } else {
            $tips[] = "✅ All equipment operating normally.";
        }
    } catch (PDOException $e) {
        $alerts[] = "⚠️ Could not load equipment status.";
    }

    // 4️⃣ REMINDERS Check
    try {
        $reminders = $pdo->query("SELECT COUNT(*) AS total FROM reminders")->fetch(PDO::FETCH_ASSOC);
        if ($reminders && (int)$reminders['total'] === 0) {
            $tips[] = "📅 No active reminders — add important tasks to stay on track.";
        }
    } catch (PDOException $e) {
        $alerts[] = "⚠️ Could not load reminders.";
    }

    // 5️⃣ WEATHER LIVE Check
    $weatherApiKey = '55ebd61504d24f17929120237251104';
    $city = 'Canberra';
    $weatherUrl = "https://api.weatherapi.com/v1/forecast.json?key={$weatherApiKey}&q={$city}&days=1";

    $weatherJson = @file_get_contents($weatherUrl);
    if ($weatherJson !== false) {
        $weatherData = json_decode($weatherJson, true);
        if (isset($weatherData['forecast']['forecastday'][0]['day'])) {
            $forecast = $weatherData['forecast']['forecastday'][0]['day'];

            if ($forecast['daily_chance_of_rain'] > 50) {
                $alerts[] = "☔ Rain expected today — avoid fertilizer spraying.";
            }
            if ($forecast['mintemp_c'] < 5) {
                $alerts[] = "🥶 Very cold weather ahead (below 5°C) — delay planting.";
            }
        } else {
            $alerts[] = "⚠️ Weather forecast data incomplete.";
        }
    } else {
        $alerts[] = "⚠️ Weather API unavailable.";
    }

    // 📦 Final JSON output
    echo json_encode([
        "tips" => $tips,
        "alerts" => $alerts
    ]);
}

// 📢 CALL THE FUNCTION
handleSuggestions($pdo);
exit;