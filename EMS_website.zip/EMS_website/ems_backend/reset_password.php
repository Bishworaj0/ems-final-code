<?php
function handlePasswordReset($pdo) {
    $data = json_decode(file_get_contents("php://input"), true);
    $username = $data['username'] ?? '';
    $newPassword = $data['new_password'] ?? '';
  
    if (!$username || !$newPassword) {
      http_response_code(400);
      echo json_encode(["error" => "Username and new password required"]);
      return;
    }
  
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ?");
    $stmt->execute([$hash, $username]);
  
    if ($stmt->rowCount()) {
      echo json_encode(["message" => "Password successfully reset"]);
    } else {
      http_response_code(404);
      echo json_encode(["error" => "User not found"]);
    }
  }