import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib

# Load your CSV data
df = pd.read_csv("crop_yeild_data.csv")

# Encode crop names (optional if only one crop)
df['crop'] = df['crop'].astype('category').cat.codes  
X = df[['avg_temperature', 'avg_humidity']]
y = df['yield_kg_per_acre']

# Train model
model = LinearRegression()
model.fit(X, y)

# Save model
joblib.dump(model, "yield_model.pkl")
print("✅ Model trained and saved.")