import sys
import joblib

# Get temperature and humidity from command line
temp = float(sys.argv[1])
humidity = float(sys.argv[2])

# Load the model
model = joblib.load("yield_model.pkl")

# Predict
prediction = model.predict([[temp, humidity]])
print(round(prediction[0], 2))