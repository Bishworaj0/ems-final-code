document.addEventListener("DOMContentLoaded", () => {
  const monthFilter = document.getElementById("monthFilter");
  const exportBtn = document.getElementById("exportBtn");

  let yieldChart, equipmentChart;

  function fetchReports(month = "") {
    let url = "/EMS_website/ems_backend/index.php?route=reports";
    if (month) {
      const [year, m] = month.split("-");
      const start = `${year}-${m}-01`;
      const end = new Date(year, m, 0).toISOString().split("T")[0];
      url += `&start=${start}&end=${end}`;
    }

    fetch(url)
      .then(res => res.json())
      .then(data => {
        if (!data.yield || !data.equipment || !data.summary) {
          console.error("Incomplete data:", data);
          return;
        }

        updateSummary(data.yield, data.summary);
        drawYieldChart(data.yield);
        drawEquipmentChart(data.equipment);
      })
      .catch(err => {
        console.error("❌ Failed to load reports:", err);
      });
  }
  
  console.log("🧪 Debug - Running updateSummary");

["summaryYieldAccuracy", "summaryReminders", "summaryLogins", "summaryCrops", "summaryEquipment"].forEach(id => {
  const el = document.getElementById(id);
  if (!el) {
    console.error(`❌ Element not found in DOM: #${id}`);
  } else {
    console.log(`✅ Found #${id}`);
  }
});

function updateSummary(yieldData, summary) {
  try {
  
    let accuracy = summary.yield_accuracy;

    if (accuracy === undefined && yieldData.estimated?.length && yieldData.actual?.length) {
      const totalEstimated = yieldData.estimated.reduce((a, b) => a + b, 0);
      const totalActual = yieldData.actual.reduce((a, b) => a + b, 0);
      accuracy = totalEstimated > 0 ? ((totalActual / totalEstimated) * 100).toFixed(1) : "0";
    }

    const mappings = {
      summaryYieldAccuracy: `${accuracy ?? "--"}%`,
      summaryReminders: summary.reminders ?? "--",
      summaryLogins: summary.user_logins?.length ?? "--",
      summaryCrops: summary.new_crops ?? "--",
      summaryEquipment: summary.equipment_updates ?? "--"
    };

    Object.entries(mappings).forEach(([id, value]) => {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = value;
      } else {
        console.warn(`⚠️ Element #${id} not found in DOM`);
      }
    });
  } catch (err) {
    console.error("❌ Failed to update summary:", err);
  }
}
  function drawYieldChart(yieldData) {
    if (yieldChart) yieldChart.destroy();
    yieldChart = new Chart(document.getElementById("yieldChart").getContext("2d"), {
      type: "bar",
      data: {
        labels: yieldData.labels,
        datasets: [
          {
            label: "Estimated",
            data: yieldData.estimated,
            backgroundColor: "#60a5fa"
          },
          {
            label: "Actual",
            data: yieldData.actual,
            backgroundColor: "#34d399"
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: "bottom" },
          title: { display: true, text: "Yield" }
        }
      }
    });
  }

  function drawEquipmentChart(data) {
    if (equipmentChart) equipmentChart.destroy();
    equipmentChart = new Chart(document.getElementById("equipmentChart").getContext("2d"), {
      type: "doughnut",
      data: {
        labels: ["Working", "Broken", "Maintenance"],
        datasets: [{
          data: [data.working, data.broken, data.maintenance],
          backgroundColor: ["#10b981", "#ef4444", "#f59e0b"]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: "bottom" },
          title: { display: true, text: "Equipment Status" }
        }
      }
    });
  }

  monthFilter.addEventListener("change", () => {
    fetchReports(monthFilter.value);
  });

  exportBtn.addEventListener("click", () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("EMS Monthly Report", 20, 20);
    doc.setFontSize(12);

    doc.text(`Yield Accuracy: ${document.getElementById("summaryYieldAccuracy").textContent}`, 20, 30);
    doc.text(`Reminders: ${document.getElementById("summaryReminders").textContent}`, 20, 38);
    doc.text(`Users Logged In: ${document.getElementById("summaryLogins").textContent}`, 20, 46);
    doc.text(`New Crops: ${document.getElementById("summaryCrops").textContent}`, 20, 54);
    doc.text(`Equipment Updates: ${document.getElementById("summaryEquipment").textContent}`, 20, 62);

    doc.addImage(yieldChart.toBase64Image(), "PNG", 20, 75, 160, 60);
    doc.addImage(equipmentChart.toBase64Image(), "PNG", 20, 140, 160, 60);
    doc.save("ems-report.pdf");
  });

  fetchReports(); 
});