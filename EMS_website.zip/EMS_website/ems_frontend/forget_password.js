document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("resetForm");
  const feedback = document.getElementById("feedback");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    feedback.textContent = "";
    feedback.className = "text-sm text-gray-500";
    feedback.innerHTML = `🔄 Resetting password...`;

    const identifier = document.getElementById("identifier").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();

    if (!identifier || !newPassword) {
      showFeedback("Please fill out all fields.", "red");
      return;
    }

    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=reset_password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ identifier, new_password: newPassword })
      });

      const result = await res.json();

      if (res.ok && result.message) {
        showFeedback(result.message, "green");
        form.reset();
      } else {
        showFeedback(result.error || "Something went wrong.", "red");
      }

    } catch (err) {
      console.error("Password reset failed:", err);
      showFeedback("⚠️ Failed to reset password. Try again later.", "red");
    }
  });

  function showFeedback(message, color) {
    feedback.textContent = message;
    feedback.className = `text-sm mt-2 text-${color}-600 text-center`;
  }
});