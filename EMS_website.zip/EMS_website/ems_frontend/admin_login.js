document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("adminLoginForm");
  const usernameInput = document.getElementById("adminUsername");
  const passwordInput = document.getElementById("adminPassword");
  const messageBox = document.getElementById("loginMessage");
  const toggleIcon = document.getElementById("togglePassword");
  const logoutBtn = document.getElementById("logoutBtn");

  if (!form || !usernameInput || !passwordInput || !messageBox) {
    console.error("⚠️ Login form elements not found.");
    return;
  }

  // 🔐 Toggle password visibility
  if (toggleIcon && passwordInput) {
    toggleIcon.addEventListener("click", () => {
      const isPassword = passwordInput.type === "password";
      passwordInput.type = isPassword ? "text" : "password";
      toggleIcon.textContent = isPassword ? "🙈" : "👁️";
    });
  }

  // 🔓 Handle form login
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    messageBox.textContent = "";

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const result = await res.json();

      if (res.ok && result.message === "Login successful" && result.user) {
        localStorage.setItem("loggedInUser", JSON.stringify({
          id: result.user.id,
          username: result.user.username,
          role: result.user.role
        }));

        messageBox.textContent = "✅ Logged in successfully!";
        console.log("🔐 Logged in as:", result.user.role);
console.log("📦 Saved to localStorage:", JSON.stringify(result.user));
        messageBox.className = "text-green-600 mt-4";

        setTimeout(() => {
          window.location.href = "admin_dashboard.html";
        }, 1000);
      } else {
        messageBox.textContent = result.error || "❌ Login failed. Please try again.";
        messageBox.className = "text-red-600 mt-4";
      }

    } catch (err) {
      console.error("❌ Login error:", err);
      messageBox.textContent = "❌ Network error. Please try again.";
      messageBox.className = "text-red-600 mt-4";
    }
  });

  // 👋 Logout
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("loggedInUser");
      alert("👋 Logged out");
      window.location.href = "admin_login.html";
    });
  }
});