document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("userLoginForm");
  const usernameInput = document.getElementById("userUsername");
  const passwordInput = document.getElementById("userPassword");
  const messageBox = document.getElementById("loginMessage");
  const loginButton = form.querySelector("button[type='submit']");

  if (!form || !usernameInput || !passwordInput || !messageBox || !loginButton) {
    console.error("❌ Missing login form elements");
    return;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    messageBox.textContent = "";
    loginButton.disabled = true;
    loginButton.textContent = "Logging in...";

    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const result = await res.json();
      console.log("🔄 Raw login response:", result);

      if (res.ok && result.message === "Login successful" && result.user) {
        const userObj = {
          id: result.user.id,
          username: result.user.username,
          role: result.user.role
        };

        console.log("✅ Logged in as:", userObj.role);
        console.log("📦 Saved to localStorage:", userObj);

        localStorage.setItem("loggedInUser", JSON.stringify(userObj));

        messageBox.textContent = "✅ Logged in successfully!";
        messageBox.className = "text-green-600 mt-4";

        setTimeout(() => {
          window.location.href = "dashboard.html";
        }, 800);
      } else {
        messageBox.textContent = result.error || "❌ Login failed. Please try again.";
        messageBox.className = "text-red-600 mt-4";
        passwordInput.value = "";
      }

    } catch (err) {
      console.error("Login error:", err);
      messageBox.textContent = "❌ Network error. Please try again.";
      messageBox.className = "text-red-600 mt-4";
    }

    loginButton.disabled = false;
    loginButton.textContent = "Login";
  });

  // 🔐 Password toggle
  const toggleIcon = document.getElementById("togglePassword");
  if (toggleIcon) {
    toggleIcon.addEventListener("click", () => {
      const isPassword = passwordInput.type === "password";
      passwordInput.type = isPassword ? "text" : "password";
      toggleIcon.textContent = isPassword ? "🙈" : "👁️";
    });
  }
});