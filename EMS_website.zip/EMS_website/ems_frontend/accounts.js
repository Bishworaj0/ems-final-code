document.addEventListener("DOMContentLoaded", () => {
  const addAccountBtn = document.getElementById("addAccountBtn");
  const modal = document.getElementById("modal");
  const modalForm = document.getElementById("modalForm");
  const closeModal = document.getElementById("closeModal");
  const modalTitle = document.getElementById("modalTitle");

  let editing = false;
  let editingId = null;

  if (addAccountBtn) {
    addAccountBtn.addEventListener("click", () => {
      modalTitle.textContent = "Add New Account";
      modalForm.reset();
      modal.classList.remove("hidden");
      editing = false;
    });
  }

  if (closeModal) {
    closeModal.addEventListener("click", () => {
      modal.classList.add("hidden");
    });
  }

  if (modalForm) {
    modalForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("modalName").value.trim();
      const amount = parseFloat(document.getElementById("modalAmount").value);
      const type = document.getElementById("modalType").value;

      if (!name || isNaN(amount)) {
        alert("❌ Please fill all fields!");
        return;
      }

      try {
        const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=accounts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ description: name, amount, type, date: new Date().toISOString().slice(0,10) })
        });

        const result = await res.json();
        alert(result.message || "✅ Saved successfully!");

        modal.classList.add("hidden");
        await loadAccounts();
      } catch (err) {
        console.error("❌ Failed to save account:", err);
        alert("❌ Network error!");
      }
    });
  }

  document.getElementById("exportBtn").addEventListener("click", exportToCSV);

  loadAccounts();
});

// 🚀 Load accounts
async function loadAccounts() {
  try {
    const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=accounts");
    const accounts = await res.json();

    const accountList = document.getElementById("accountList");
    if (!accountList) return;

    accountList.innerHTML = "";

    let totalIncome = 0;
    let totalExpenses = 0;

    accounts.forEach(acc => {
      const li = document.createElement("li");
      li.className = "p-3 border-b flex justify-between";

      li.innerHTML = `
        <div class="flex flex-col">
          <span class="font-semibold">${acc.description}</span>
          <small class="text-gray-500">${acc.date}</small>
        </div>
        <div class="${acc.type === 'income' ? 'text-green-600' : 'text-red-600'} font-semibold">
          ${acc.type === 'income' ? '+' : '-'}$${parseFloat(acc.amount).toFixed(2)}
        </div>
      `;
      accountList.appendChild(li);

      if (acc.type === 'income') totalIncome += parseFloat(acc.amount);
      else totalExpenses += parseFloat(acc.amount);
    });

    document.getElementById("totalIncome").textContent = `$${totalIncome.toFixed(2)}`;
    document.getElementById("totalExpenses").textContent = `$${totalExpenses.toFixed(2)}`;
    document.getElementById("netBalance").textContent = `$${(totalIncome - totalExpenses).toFixed(2)}`;

    const profitLoss = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0;
    document.getElementById("profitLoss").textContent = `${profitLoss.toFixed(1)}%`;

    updateChart(totalIncome, totalExpenses);

  } catch (err) {
    console.error("❌ Failed to load accounts:", err);
    alert("❌ Error loading accounts.");
  }
}

// 📊 Chart
let barChart;
function updateChart(totalIncome, totalExpenses) {
  const ctx = document.getElementById("incomeExpenseBarChart").getContext("2d");
  if (barChart) {
    barChart.destroy();
  }
  barChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Income', 'Expenses'],
      datasets: [{
        label: 'Amount ($)',
        data: [totalIncome, totalExpenses],
        backgroundColor: [
          'rgba(34,197,94,0.8)', 
          'rgba(239,68,68,0.8)'
        ],
        borderRadius: 8,
        barThickness: 40
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 500 } // adjust based on your money range
        }
      }
    }
  });
}

// 📥 Export CSV
function exportToCSV() {
  const items = document.querySelectorAll("#accountList li");
  let csv = "Description,Date,Type,Amount\n";

  items.forEach(li => {
    const desc = li.querySelector("span").textContent;
    const date = li.querySelector("small").textContent;
    const amountText = li.querySelector("div.font-semibold").textContent;
    const type = amountText.startsWith('+') ? 'income' : 'expense';
    const amount = amountText.replace('+', '').replace('-', '').replace('$', '').trim();
    csv += `${desc},${date},${type},${amount}\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "accounts.csv";
  link.click();
}