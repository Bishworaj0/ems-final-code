document.addEventListener("DOMContentLoaded", () => {
  const loadingSpinner = document.getElementById("loadingSpinner");
  const tipsContainer = document.getElementById("tipsContainer");
  const alertsContainer = document.getElementById("alertsContainer");
  const refreshBtn = document.getElementById("refreshBtn");

  console.log("🚀 Suggestions page loaded.");

  function loadSuggestions() {
    loadingSpinner.style.display = "flex"; // 🌀 Show spinner
    tipsContainer.innerHTML = "";
    alertsContainer.innerHTML = "";

    fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=suggestions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    })
    .then(res => res.json())
    .then(data => {
      console.log("🧪 Raw suggestions:", data);

      loadingSpinner.style.display = "none"; // 🌀 Hide spinner

      if (data.tips && data.tips.length > 0) {
        data.tips.forEach(tip => {
          const card = createCard(tip, "tip");
          tipsContainer.appendChild(card);
        });
      } else {
        tipsContainer.innerHTML = "<p class='text-green-600'>✅ No tips at the moment!</p>";
      }

      if (data.alerts && data.alerts.length > 0) {
        data.alerts.forEach(alert => {
          const card = createCard(alert, "alert");
          alertsContainer.appendChild(card);
        });
      } else {
        alertsContainer.innerHTML = "<p class='text-blue-600'>✅ No alerts currently!</p>";
      }
    })
    .catch(err => {
      console.error("❌ Failed to fetch suggestions:", err);
      loadingSpinner.style.display = "none";
      tipsContainer.innerHTML = "<p class='text-red-500'>Error loading suggestions.</p>";
      alertsContainer.innerHTML = "<p class='text-red-500'>Error loading suggestions.</p>";
    });
  }

  function createCard(text, type) {
    const div = document.createElement("div");
    div.className = `rounded-lg shadow-md p-4 mb-4 ${type === "tip" ? "bg-green-100" : "bg-yellow-100"} hover:shadow-lg transition`;

    const p = document.createElement("p");
    p.className = "text-gray-800";
    p.textContent = text;

    div.appendChild(p);
    return div;
  }

  // ✅ Load initially
  loadSuggestions();

  // ✅ Refresh Button click event
  if (refreshBtn) {
    refreshBtn.addEventListener("click", () => {
      console.log("🔄 Refresh button clicked!");
      loadSuggestions();
    });
  }
});