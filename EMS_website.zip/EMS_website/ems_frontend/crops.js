document.addEventListener("DOMContentLoaded", () => {
  loadCrops();

  const form = document.getElementById("addCropForm");
  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const crop_name = document.getElementById("cropName").value.trim();
      const season = document.getElementById("season").value.trim();
      const quantity = parseFloat(document.getElementById("quantity").value);
      const planted_on = document.getElementById("plantedOn").value;
      const harvested_on = document.getElementById("harvestedOn").value;
      const notes = document.getElementById("notes").value.trim();

      if (!crop_name || isNaN(quantity) || !planted_on || !harvested_on) {
        alert("Please fill all required fields!");
        return;
      }

      try {
        const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=crops", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ crop_name, season, quantity, planted_on, harvested_on, notes })
        });

        const result = await res.json();
        alert(result.message || "Crop added successfully!");

        form.reset();
        await loadCrops();
      } catch (err) {
        console.error("❌ Failed to save crop:", err);
        alert("Network error while adding crop.");
      }
    });
  }

  const searchInput = document.getElementById("cropSearch");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      loadCrops(searchInput.value.trim().toLowerCase());
    });
  }
});

// 🔄 Load all crops (with optional filter)
async function loadCrops(searchTerm = "") {
  try {
    const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=crops");
    const crops = await res.json();

    const list = document.getElementById("cropList");
    if (!list) return;

    list.innerHTML = "";
    const filteredCrops = crops.filter(crop =>
      crop.crop_name.toLowerCase().includes(searchTerm) ||
      crop.season.toLowerCase().includes(searchTerm)
    );

    if (filteredCrops.length === 0) {
      list.innerHTML = `<tr><td colspan="5" class="text-center text-gray-400 py-6">No crops found.</td></tr>`;
      renderChart([]);
      return;
    }

    filteredCrops.forEach(crop => {
      const tr = document.createElement("tr");
      tr.className = "hover:bg-gray-100 dark:hover:bg-gray-700";
      tr.innerHTML = `
        <td class="p-3">${crop.crop_name}</td>
        <td class="p-3">${crop.season}</td>
        <td class="p-3">${crop.quantity}</td>
        <td class="p-3">${crop.planted_on}</td>
        <td class="p-3">${crop.harvested_on}</td>
      `;
      list.appendChild(tr);
    });

    renderChart(filteredCrops);

  } catch (err) {
    console.error("❌ Failed to load crops:", err);
    alert("Error loading crops.");
  }
}

// 📊 Chart render
let cropChart;
function renderChart(crops) {
  const ctx = document.getElementById("cropChart")?.getContext("2d");
  if (!ctx) return;

  if (cropChart) {
    cropChart.destroy();
  }

  cropChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: crops.map(c => c.crop_name),
      datasets: [{
        label: "Quantity",
        data: crops.map(c => c.quantity),
        backgroundColor: "rgba(34,197,94,0.8)"
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}