document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("addUserForm");
  const table = document.getElementById("userTable");

  function showToast(message, type = "success") {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.className = `fixed top-5 right-5 px-4 py-2 rounded shadow-lg text-white z-50 ${
      type === "error" ? "bg-red-600" : "bg-green-600"
    }`;
    toast.style.display = "block";
    setTimeout(() => (toast.style.display = "none"), 3000);
  }

  function getStatusBadge(status) {
    switch (status) {
      case "active":
        return `<span class="status-badge status-active">Active</span>`;
      case "suspended":
        return `<span class="status-badge status-suspended">Suspended</span>`;
      case "pending":
        return `<span class="status-badge status-pending">Pending</span>`;
      default:
        return `<span class="status-badge bg-gray-200 text-gray-600">${status}</span>`;
    }
  }
  async function loadUsers() {
    table.innerHTML = `<tr><td colspan="7" class="text-center p-4 text-gray-500">Loading...</td></tr>`;
    try {
      const res = await fetch("/EMS_website/ems_backend/index.php?route=users");
      const users = await res.json();
  
      if (!Array.isArray(users)) {
        showToast("Server response was not a list", "error");
        console.error("Server response was not a list:", users);
        return;
      }
  
      table.innerHTML = "";
      users.forEach(user => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td class="p-2 border-b">${user.id}</td>
          <td class="p-2 border-b">${user.username}</td>
          <td class="p-2 border-b">${user.email || "-"}</td>
          <td class="p-2 border-b">${user.role}</td>
          <td class="p-2 border-b">${getStatusBadge(user.status)}</td>
          <td class="p-2 border-b">${user.last_login || "--"}</td>
          <td class="p-2 border-b text-right">
            <button onclick="deleteUser(${user.id})" class="text-red-500 hover:underline">🗑 Delete</button>
          </td>
        `;
        table.appendChild(row);
      });
    } catch (err) {
      showToast("❌ Failed to load users", "error");
      console.error(err);
    }
  }

  form.addEventListener("submit", async e => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const role = document.getElementById("role").value;
    const userStatus = document.getElementById("status").value;
    
    console.log({ username, email, password, role, userStatus }); 

    if (!username || !email || !password) {
      showToast("Please fill in all fields", "error");
      return;
    }

    try {
      const res = await fetch("/EMS_website/ems_backend/index.php?route=users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          email,
          password,
          role,
         userStatus,
          admin_role_check: "admin"
        })
      });
      const result = await res.json();

      if (res.ok) {
        showToast("✅ User added successfully!");
        form.reset();
        loadUsers();
      } else {
        showToast(result.error || "Failed to add user", "error");
      }
    } catch (err) {
      showToast("Server error", "error");
      console.error(err);
    }
  });

  window.deleteUser = async (id) => {
    if (!confirm("Are you sure you want to delete this user?")) return;

    try {
      const res = await fetch("/EMS_website/ems_backend/index.php?route=users", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, admin_role_check: "admin" })
      });
      const result = await res.json();

      if (res.ok) {
        showToast("🗑 User deleted");
        loadUsers();
      } else {
        showToast(result.error || "Delete failed", "error");
      }
    } catch (err) {
      showToast("Error deleting user", "error");
      console.error(err);
    }
  };

  loadUsers();
});