document.addEventListener("DOMContentLoaded", () => {
  // 🔐 Check for logged-in admin user
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if (!user) {
    alert("Please log in first.");
    window.location.href = "index.html";
  }

  // ✅ Show logged-in admin info
  const loggedInText = document.getElementById("loggedInUser");
  if (loggedInText) {
    loggedInText.textContent = `Logged in as: ${user.fullname || user.username} (${user.role})`;
  }
// 👥 Total Users
fetch("/EMS_website/ems_backend/index.php?route=users")
  .then(res => {
    if (!res.ok) throw new Error("Not authorized or failed");
    return res.json();
  })
  .then(data => {
    const userCountEl = document.getElementById("userCount");
    if (userCountEl) userCountEl.textContent = data.length;
  })
  .catch(err => {
    console.error("❌ Failed to load user count:", err);
  });

  // 🌾 Total Crops
  fetch("/EMS_website/ems_backend/index.php?route=crops")
    .then(res => res.json())
    .then(data => {
      const cropCountEl = document.getElementById("cropCount");
      if (cropCountEl) cropCountEl.textContent = data.length;
    })
    .catch(err => console.error("Failed to fetch crops:", err));

  // 📊 Yield Forecast Chart
  fetch("/EMS_website/ems_backend/index.php?route=yield_forecast")
    .then(res => res.json())
    .then(data => {
      const labels = [], estimated = [], actual = [];
      let totalAccuracy = 0;

      data.forEach(item => {
        if (item.estimated_yield > 0) {
          labels.push(item.crop_name);
          estimated.push(parseFloat(item.estimated_yield));
          actual.push(parseFloat(item.actual_yield));
          totalAccuracy += (item.actual_yield / item.estimated_yield) * 100;
        }
      });

      const avgAccuracy = (totalAccuracy / labels.length).toFixed(1);
      const yieldAccuracyEl = document.getElementById("yieldAccuracy");
      if (yieldAccuracyEl) yieldAccuracyEl.textContent = avgAccuracy + "%";

      const chartCanvas = document.getElementById("forecastChart");
      if (chartCanvas) {
        new Chart(chartCanvas, {
          type: "bar",
          data: {
            labels,
            datasets: [
              { label: "Estimated", data: estimated, backgroundColor: "#60a5fa" },
              { label: "Actual", data: actual, backgroundColor: "#34d399" }
            ]
          },
          options: {
            responsive: true,
            plugins: { legend: { position: "bottom" } }
          }
        });
      }
    })
    .catch(err => console.error("Failed to load forecast:", err));

  // 🚜 Equipment Health
  fetch("/EMS_website/ems_backend/index.php?route=equipment_status")
    .then(res => res.json())
    .then(data => {
      const working = data.filter(e => e.status === "Working").length;
      const percent = ((working / data.length) * 100).toFixed(1);
      const equipmentStatusEl = document.getElementById("equipmentStatus");
      if (equipmentStatusEl) equipmentStatusEl.textContent = percent + "%";

      const table = document.getElementById("equipmentTable");
      if (table) {
        data.forEach(eq => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td class="p-2">${eq.name}</td>
            <td class="p-2">${eq.type}</td>
            <td class="p-2">${eq.status}</td>
            <td class="p-2">${eq.last_serviced || '-'}</td>
          `;
          table.appendChild(row);
        });
      }
    })
    .catch(err => console.error("Equipment fetch error:", err));

  

  // 📅 Month Filter 
  const filterMonth = document.getElementById("filterMonth");
  if (filterMonth) {
    filterMonth.addEventListener("change", () => {
      const selectedMonth = filterMonth.value;
      console.log("Selected month:", selectedMonth);
      // You could trigger report filtering here later
    });
  }
  let activityPage = 1;

  function timeAgo(datetime) {
    const seconds = Math.floor((new Date() - new Date(datetime)) / 1000);
    const intervals = [
      { label: 'y', secs: 31536000 },
      { label: 'm', secs: 2592000 },
      { label: 'd', secs: 86400 },
      { label: 'h', secs: 3600 },
      { label: 'm', secs: 60 },
      { label: 's', secs: 1 },
    ];
    for (const { label, secs } of intervals) {
      const count = Math.floor(seconds / secs);
      if (count > 0) return `${count}${label} ago`;
    }
    return 'just now';
  }
  
  async function loadActivities() {
    try {
      const res = await fetch(
        `/EMS_website/ems_backend/index.php?route=activities&limit=5&page=${activityPage}`
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      
      const data = await res.json();
      console.log("🧪 Fetched activities:", data);
      
      if (!Array.isArray(data)) {
        console.error("❌ Expected an array but got:", typeof data, data);
        return;
      }
  
      const ul = document.getElementById('activityList');
  
      data.forEach(act => {
        const li = document.createElement('li');
        const icons = {
          login: "🚪",
          logout: "👋",
          add_crop: "🌾",
          delete_crop: "🗑️",
          update_equipment: "🔧",
          view_forecast: "📈",
          default: "📝"
        };
        
        const icon = icons[act.action] || icons.default;
        
        li.innerHTML = `
          <span class="font-medium">${act.username}</span> ${icon} ${act.description}
          <span class="text-xs text-gray-500">· ${timeAgo(act.created_at)}</span>
        `;
        ul.appendChild(li);
      });
  
      if (data.length === 5) {
        activityPage++;
      } else {
        const loadMoreBtn = document.getElementById('loadMore');
        loadMoreBtn.disabled = true;
        loadMoreBtn.textContent = 'No more';
      }
  
    } catch (e) {
      console.error('❌ loadActivities error:', e);
    }
  }
  
  // init
  document.getElementById('loadMore').addEventListener('click', loadActivities);
  loadActivities();
  
  
  })
 
