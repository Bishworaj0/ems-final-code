document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("reminderModal");
  const form = document.getElementById("reminderForm");
  const list = document.getElementById("reminderList");
  const newReminderBtn = document.getElementById("newReminderBtn");
  const cancelBtn = document.getElementById("cancelBtn");
  const enableBtn = document.getElementById("enableNotificationsBtn");
  const emailInput = document.getElementById("reminderEmail");
  const notifiedReminders = new Set();

  // 🌦️ Smart suggestion based on time of day
  function suggestTime() {
    const now = new Date();
    const morning = new Date();
    morning.setHours(8, 0, 0);

    const evening = new Date();
    evening.setHours(18, 0, 0);

    return now.getHours() < 12 ? morning.toISOString().slice(0, 16) : evening.toISOString().slice(0, 16);
  }

  // 🔔 Request Notification Permission
  enableBtn?.addEventListener("click", () => {
    if ("Notification" in window) {
      Notification.requestPermission().then(p => alert("Notifications: " + p));
    }
  });

  newReminderBtn?.addEventListener("click", () => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
    document.getElementById("date_time").value = suggestTime(); // suggest smart time
    modal.classList.remove("hidden");
  });

  cancelBtn?.addEventListener("click", () => modal.classList.add("hidden"));

  // ✅ Form submission
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const title = document.getElementById("title").value.trim();
    const date_time = document.getElementById("date_time").value;
    const notes = document.getElementById("notes").value.trim();
    const email = emailInput.value.trim();

    if (!title || !date_time) return alert("Fill all fields.");

    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=reminders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, date_time, notes, email})
      });

      const result = await res.json();
      alert(result.message || "Reminder added and email will be sent.");
      form.reset();
      modal.classList.add("hidden");
      emailInput.value = "";
      loadReminders();
    } catch (err) {
      console.error("Submit error:", err);
      alert("Failed to save reminder.");
    }
  });

  // 📥 Load reminders
  async function loadReminders() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=reminders");
      const reminders = await res.json();

      list.innerHTML = "";
      const now = new Date();
      const threshold = new Date(now.getTime() + 5 * 60 * 1000);

      reminders.forEach(reminder => {
        const dt = new Date(reminder.date_time);
        const id = reminder.id;

        if (dt >= now && dt <= threshold && !notifiedReminders.has(id)) {
          showNotification(reminder.title, reminder.notes, dt);
          notifiedReminders.add(id);
        }

        const li = document.createElement("li");
        li.className = "bg-white p-4 rounded shadow flex justify-between items-start";
        li.innerHTML = `
          <div>
            <h3 class="text-lg font-bold">${reminder.title}</h3>
            <p class="text-sm text-gray-600">${dt.toLocaleString()}</p>
            <p class="text-gray-700 mt-1">${reminder.notes}</p>
          </div>
          <button onclick="deleteReminder(${id})" class="text-red-600 hover:text-red-800">
            <i class="fas fa-trash"></i>
          </button>
        `;
        list.appendChild(li);
      });

    } catch (err) {
      console.error("Load error:", err);
      alert("Error loading reminders.");
    }
  }

  // 🔔 Show browser notification
  function showNotification(title, body, time) {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(`⏰ ${title}`, {
        body: `${body || "Reminder"} at ${time.toLocaleTimeString()}`,
        icon: "https://cdn-icons-png.flaticon.com/512/1827/1827349.png"
      });
    }
  }

  // 🗑️ Delete reminder
  window.deleteReminder = async function (id) {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=reminders", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      const result = await res.json();
      alert(result.message || "Deleted");
      loadReminders();
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };
  

  loadReminders();
  setInterval(loadReminders, 60000);
});