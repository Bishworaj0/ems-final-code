document.addEventListener("DOMContentLoaded", async () => {
  const cropSelect = document.getElementById("cropSelect");
  const predictForm = document.getElementById("predictForm");
  const loading = document.getElementById("loading");
  const result = document.getElementById("result");
  const predictedYieldEl = document.getElementById("predictedYield");
  const confidenceEl = document.getElementById("confidence");
  const predictedTempEl = document.getElementById("predictedTemp");
  const predictedWeatherEl = document.getElementById("predictedWeather");
  const historyList = document.getElementById("historyList");

  let yieldChart;

  // 🧠 Load crops
  async function loadCrops() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=crops");
      const crops = await res.json();

      cropSelect.innerHTML = "<option value=''>-- Select Crop --</option>";

      crops.forEach(crop => {
        const option = document.createElement("option");
        option.value = crop.crop_name;
        option.textContent = crop.crop_name;
        cropSelect.appendChild(option);
      });
    } catch (err) {
      console.error("Failed to load crops:", err);
      cropSelect.innerHTML = "<option value=''>⚠️ Error loading crops</option>";
    }
  }

  await loadCrops();

  // 🚀 Handle prediction
  predictForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const crop = cropSelect.value;
    if (!crop) {
      alert("Please select a crop!");
      return;
    }

    loading.classList.remove("hidden");
    result.classList.add("hidden");

    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=yield_forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ crop, past_yield: 50 }) 
      });

      const data = await res.json();

      if (data.error) {
        alert(data.error);
      } else {
        predictedYieldEl.textContent = data.predicted_yield;
        confidenceEl.textContent = data.confidence;
        predictedTempEl.textContent = data.temp;
        predictedWeatherEl.textContent = data.weatherDesc;
        result.classList.remove("hidden");
        await fetchHistory();
      }
    } catch (err) {
      console.error("Prediction error:", err);
      alert("Failed to predict yield!");
    }

    loading.classList.add("hidden");
  });

  // 🕰️ Fetch history
  async function fetchHistory() {
    
    try {
      
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=yield_forecast");
     
      const history = await res.json();
      

      historyList.innerHTML = "";

      const cropNames = [];
      const yields = [];

      history.forEach(entry => {
        const li = document.createElement("li");
        li.className = "p-2 bg-gray-100 rounded flex justify-between items-center";
        li.innerHTML = `
          <div>
            <strong>${entry.crop}</strong> • Predicted: ${entry.predicted_yield} units
          </div>
          <small>${new Date(entry.created_at).toLocaleDateString()}</small>
        `;
        historyList.appendChild(li);

        cropNames.push(entry.crop);
        yields.push(entry.predicted_yield);
      });

      renderChart(cropNames, yields);
    } catch (err) {
      console.error("History load error", err);
    }
  }


  // 📊 Render chart
  function renderChart(labels, data) {
    const ctx = document.getElementById('yieldChart').getContext('2d');

    if (yieldChart) {
      yieldChart.destroy();
    }

    yieldChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Predicted Yield',
          data: data,
          backgroundColor: 'rgba(34,197,94,0.8)'
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'top' } }
      }
    });
  }

  await fetchHistory();
});