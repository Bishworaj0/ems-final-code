document.addEventListener("DOMContentLoaded", async () => {
  const userData = JSON.parse(localStorage.getItem("loggedInUser"));

  if (!userData) {
    alert("❌ Session expired. Please login again.");
    window.location.href = "index.html";
    return;
  }

  console.log("👤 Logged In User:", userData.username);

  // Setup IDs
  const cropCountEl = document.getElementById("cropCount");
  const totalIncomeEl = document.getElementById("totalIncome");
  const equipmentCountEl = document.getElementById("equipmentCount");
  const reminderCountEl = document.getElementById("reminderCount");
  const calendarEl = document.getElementById("realTimeCalendar");
  const chatModal = document.getElementById("chatModal");
  const openBtn = document.getElementById("openChatBtn");
  const closeBtn = document.getElementById("closeChatBtn");

  openBtn?.addEventListener("click", () => {
    chatModal?.classList.toggle("hidden");
  });

  closeBtn?.addEventListener("click", () => {
    chatModal?.classList.add("hidden");
  });

  //  Fetch Crops
  async function loadCropCount() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=crops");
      const crops = await res.json();
      if (cropCountEl) cropCountEl.textContent = crops.length || 0;
    } catch (err) {
      console.error("🌾 Failed to fetch crops:", err);
      if (cropCountEl) cropCountEl.textContent = "0";
    }
  }

  // Fetch Equipment
  async function loadEquipmentCount() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=equipment_status");
      const data = await res.json();
  
      console.log("🚜 Equipment response:", data);
  
      if (Array.isArray(data)) {
        document.getElementById("equipmentCount").textContent = data.length;
      } else {
        console.warn("Unexpected equipment response:", data);
      }
    } catch (err) {
      console.error("Failed to fetch equipment:", err);
    }
  }

  //  Fetch Income
  async function loadIncome() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=accounts");
      const accounts = await res.json();
      let total = 0;
      accounts.forEach(acc => {
        if (acc.type === "income") {
          total += parseFloat(acc.amount);
        }
      });
      if (totalIncomeEl) totalIncomeEl.textContent = `$${total.toFixed(2)}`;
    } catch (err) {
      console.error("💰 Failed to fetch income:", err);
      if (totalIncomeEl) totalIncomeEl.textContent = "$0";
    }
  }

  // Fetch Reminders
  async function loadReminders() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=reminders");
      const reminders = await res.json();
      if (reminderCountEl) reminderCountEl.textContent = reminders.length || 0;
    } catch (err) {
      console.error("📅 Failed to fetch reminders:", err);
      if (reminderCountEl) reminderCountEl.textContent = "0";
    }
  }

  // Calendar Clock
  function startClock() {
    if (!calendarEl) return;
    setInterval(() => {
      const now = new Date();
      calendarEl.textContent = now.toLocaleString('en-US', {
        weekday: "long", year: "numeric", month: "long",
        day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit"
      });
    }, 1000);
  }

  // Charts
  function setupCharts() {
    const donutCtx = document.getElementById("donutChart")?.getContext('2d');
    if (donutCtx) {
      new Chart(donutCtx, {
        type: "doughnut",
        data: {
          labels: ["Productivity", "Efficiency", "Sustainability"],
          datasets: [{
            data: [87, 92, 79],
            backgroundColor: [
              "rgba(34,197,94,0.8)",
              "rgba(59,130,246,0.8)",
              "rgba(253,186,116,0.8)"
            ]
          }]
        },
        options: { responsive: true }
      });
    }
  }
  async function loadWeeklyGrowth() {
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/index.php?route=weekly_growth");
      const result = await res.json();
  
      if (!result.labels || !result.data) {
        console.warn("No weekly data");
        return;
      }
  
      new Chart(document.getElementById("barChart").getContext("2d"), {
        type: "line",
        data: {
          labels: result.labels,
          datasets: [{
            label: "Wheat Growth (kg)",
            data: result.data,
            fill: true,
            borderColor: "#10b981",
            backgroundColor: "rgba(16,185,129,0.2)",
            tension: 0.3,
            pointRadius: 5,
            pointBackgroundColor: "#10b981"
          }]
        },
        options: {
          responsive: true,
          plugins: {
            title: {
              display: true,
              text: "🌱 Weekly Yield Growth (Wheat)"
            }
          }
        }
      });
    } catch (err) {
      console.error("Weekly growth load error:", err);
    }
  }
  
  loadWeeklyGrowth();

  //  Logout Button
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      if (confirm("Do you really want to logout?")) {
        localStorage.removeItem("loggedInUser");
        window.location.href = "index.html";
      }
    });
  }
 // ⏱️ Email check every minute
 setInterval(() => {
  fetch("http://localhost:8888/EMS_website/ems_backend/send_reminders.php")
    .then(res => res.json())
    .then(data => {
      console.log("📧 Email reminder check:", data.message);
    })
    .catch(err => {
      console.warn("⚠️ Email check failed:", err);
    });
}, 10000);


  //  Initial Load
  await loadCropCount();
  await loadEquipmentCount();
  await loadIncome();
  await loadReminders();
  startClock();
  setupCharts();
});
  const API_KEY ="AIzaSyBpj3KpzC3MX5grreR7VR8vI4AeoX8U6"; 
  
  const API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent";
  document.getElementById("chatForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = document.getElementById("chatInput").value.trim();
    const chatBox = document.getElementById("chatMessages");
    if (!input) return;
  
    // Show user message
    const userMsg = document.createElement("div");
    userMsg.className = "text-right my-2 opacity-0 transition-opacity duration-300";
    userMsg.innerHTML = `<span class="inline-block bg-green-100 text-green-800 px-3 py-2 rounded-lg shadow">${input}</span>`;
    chatBox.appendChild(userMsg);
    setTimeout(() => userMsg.classList.remove("opacity-0"), 10);
  
    // Clear input
    document.getElementById("chatInput").value = "";
  
    // Typing indicator
    const typingEl = document.createElement("div");
    typingEl.className = "text-left my-2 text-sm italic text-gray-500 animate-pulse";
    typingEl.textContent = "EMS Bot is typing...";
    chatBox.appendChild(typingEl);
    chatBox.scrollTop = chatBox.scrollHeight;
  
    try {
      const res = await fetch("http://localhost:8888/EMS_website/ems_backend/chatbot_proxy.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: input })
      });
  
      const raw = await res.text();
      const data = JSON.parse(raw);
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "🤖 No reply.";
  
      // Remove typing indicator
      chatBox.removeChild(typingEl);
  
      // Show bot message
      const botMsg = document.createElement("div");
      botMsg.className = "text-left my-2 opacity-0 transition-opacity duration-300";
      botMsg.innerHTML = `<span class="inline-block bg-gray-200 text-gray-800 px-3 py-2 rounded-lg shadow">${text}</span>`;
      chatBox.appendChild(botMsg);
      setTimeout(() => botMsg.classList.remove("opacity-0"), 10);
  
      chatBox.scrollTop = chatBox.scrollHeight;
    } catch (err) {
      console.error("❌ Chat error:", err);
      typingEl.textContent = "❌ Bot failed to respond.";
    }
  });