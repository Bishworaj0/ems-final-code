document.addEventListener('DOMContentLoaded', () => {
  const API_KEY = '55ebd61504d24f17929120237251104';
  const location = 'Canberra'; 
  let unit = 'metric'; // metric = Celsius, imperial = Fahrenheit

  const currentWeatherEl = document.getElementById('currentWeatherDetails');
  const currentIconEl = document.getElementById('currentWeatherIcon');
  const forecastContainer = document.getElementById('forecastContainer');
  const toggleUnitBtn = document.getElementById('toggleUnit');

  function fetchWeather() {
    const url = `https://api.weatherapi.com/v1/forecast.json?key=${API_KEY}&q=${location}&days=5`;

    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);
        return res.json();
      })
      .then(data => {
        updateCurrent(data.current, data.location);
        updateForecast(data.forecast.forecastday);
      })
      .catch(err => {
        console.error("❌ Weather fetch error:", err);
        currentWeatherEl.innerHTML = `<p>Error fetching weather: ${err.message}</p>`;
        forecastContainer.innerHTML = `<p>Error fetching forecast data: ${err.message}</p>`;
      });
  }

  function updateCurrent(current, locationData) {
    const temp = unit === 'metric' ? `${Math.round(current.temp_c)}°C` : `${Math.round(current.temp_f)}°F`;
    const description = current.condition.text;
    const iconUrl = current.condition.icon;

    currentWeatherEl.innerHTML = `
      <p class="text-lg font-semibold">${locationData.name}</p>
      <p class="text-3xl font-bold">${temp}</p>
      <p class="capitalize">${description}</p>
    `;

    currentIconEl.innerHTML = `
      <img src="https:${iconUrl}" alt="${description}" class="mx-auto" />
    `;
  }

  function updateForecast(days) {
    forecastContainer.innerHTML = '';

    days.forEach(day => {
      const date = new Date(day.date);
      const dayName = date.toLocaleDateString(undefined, { weekday: 'long' });
      const temp = unit === 'metric'
        ? `${day.day.avgtemp_c}°C`
        : `${day.day.avgtemp_f}°F`;
      const icon = day.day.condition.icon;
      const description = day.day.condition.text;

      const card = document.createElement('div');
      card.className = 'bg-blue-50 p-4 rounded-lg shadow text-center';
      card.innerHTML = `
        <p class="font-semibold">${dayName}</p>
        <img class="mx-auto" src="https:${icon}" alt="${description}" />
        <p class="text-2xl font-bold">${temp}</p>
        <p class="capitalize text-gray-600">${description}</p>
      `;

      forecastContainer.appendChild(card);
    });
  }

  toggleUnitBtn.addEventListener('click', () => {
    unit = unit === 'metric' ? 'imperial' : 'metric';
    toggleUnitBtn.textContent = `Toggle °C/°F (Now ${unit === 'metric' ? '°C' : '°F'})`;
    fetchWeather();
  });

  fetchWeather();
});
