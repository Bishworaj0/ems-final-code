document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("loggedInUser")) || { username: "Guest", email: "guest@example.com" };

  const sidebarButtons = document.querySelectorAll(".sidebar-btn");
  const profileSection = document.getElementById("profileSection");
  const notificationsSection = document.getElementById("notificationsSection");
  const passwordSection = document.getElementById("passwordSection");
  const darkModeToggle = document.getElementById("darkModeToggle");

  const profileUsername = document.getElementById("profileUsername");
  const profileEmail = document.getElementById("profileEmail");

  const emailNotif = document.getElementById("emailNotif");
  const smsNotif = document.getElementById("smsNotif");
  const saveNotifBtn = document.getElementById("saveNotif");

  const passwordForm = document.getElementById("passwordForm");

  // Load profile info
  profileUsername.textContent = user.username;
  profileEmail.textContent = user.email || "N/A";

  // Load notification preferences
  emailNotif.checked = JSON.parse(localStorage.getItem("emailNotif")) ?? true;
  smsNotif.checked = JSON.parse(localStorage.getItem("smsNotif")) ?? false;

  // Section switching
  sidebarButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-section");
      profileSection.classList.add("hidden");
      notificationsSection.classList.add("hidden");
      passwordSection.classList.add("hidden");

      if (target === "profile") profileSection.classList.remove("hidden");
      if (target === "notifications") notificationsSection.classList.remove("hidden");
      if (target === "password") passwordSection.classList.remove("hidden");

      sidebarButtons.forEach(b => b.classList.remove("bg-blue-100"));
      btn.classList.add("bg-blue-100");
    });
  });

  // Dark mode toggle
  darkModeToggle.addEventListener("click", () => {
    document.documentElement.classList.toggle("dark");
    
    // Dynamic button text
    if (document.documentElement.classList.contains("dark")) {
      darkModeToggle.innerHTML = "☀️ Toggle Light Mode";
    } else {
      darkModeToggle.innerHTML = "🌙 Toggle Dark Mode";
    }
  });

  // Save notifications
  saveNotifBtn.addEventListener("click", () => {
    localStorage.setItem("emailNotif", emailNotif.checked);
    localStorage.setItem("smsNotif", smsNotif.checked);
    alert("✅ Notification settings saved!");
  });

  // Handle password change
  passwordForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const oldPass = document.getElementById("oldPassword").value;
    const newPass = document.getElementById("newPassword").value;

    if (oldPass.length < 6 || newPass.length < 6) {
      alert("Password must be at least 6 characters!");
      return;
    }

    alert("✅ Password change request submitted!");
    passwordForm.reset();
  });

  // Default section
  profileSection.classList.remove("hidden");
});