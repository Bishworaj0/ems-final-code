<?php
echo password_hash("bishwo123", PASSWORD_DEFAULT);
